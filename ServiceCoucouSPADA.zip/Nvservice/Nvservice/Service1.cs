﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Nvservice
{
    public partial class Nvservice : ServiceBase
    {
        
        public Nvservice()
        {
            InitializeComponent();

            if (!System.Diagnostics.EventLog.SourceExists("MonProjet"))
            {
                System.Diagnostics.EventLog.CreateEventSource(
                    "MonProjet", "LogCoucou");
            }

            eventLog1.Source = "MonProjet";

        }
        protected override void OnStart(string[] args)
        {
            int i = 1;

            while (i==1)
            {
                eventLog1.WriteEntry("Coucou\n");
                Thread.Sleep(60000);
            }

        }
        protected override void OnStop()
        {
            
        }
    }
}
